/* 
 * File:   IOs.h
 * Author: Ammar Elzeftawy, David Kim, Yaseen ElSherif
 *
 * Created on October 10, 2022, 6:32 PM
 */

#ifndef IOS_H
#define	IOS_H

#ifdef	__cplusplus
extern "C" {
#endif

void IOinit();
void IOCheck();

extern int CNflag;

#ifdef	__cplusplus
}
#endif

#endif	/* IOS_H */